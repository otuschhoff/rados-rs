// Command p02-verify validates the checked-in P02 oracle and fixture evidence.
package main

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"maps"
	"os"
	"path/filepath"
	"slices"
)

const (
	fixtureDirectory         = "testdata/p02"
	upstreamFixtureDirectory = "testdata/p02/upstream"
	evidencePath             = "docs/p02/evidence.json"
	oracleSHA256             = "7a14c655f4e93e7f350ebdc9e74ef233733ef19611ab9b7ebfe7b16c5cd9a8b7"
	dockerfileSHA256         = "bfaa51f4f49af164a94e82156c745e2ea21c620dac561658a37b230f3fd579a8"
	repositorySHA256         = "83240f736d211998dd5bbb89773696b9e11463d24dac6eeb8eb93125d4540d3b"
	upstreamOracleSHA256     = "043d94bfb9f590e9987e7ae15509d3a75813c1765e43a99ba4d7fbe06d49ee34"
	upstreamDockerfileSHA256 = "56c8b8d8f461c41c35991cf46781eb556e6267940e32a92a9c5fc3b67ca505e5"
	upstreamReproduceSHA256  = "8f5e3f8404872c51bfc9c8bca7cdb2a505dee70d4e9a8f847f13687d4243b2b7"
	generatorTool            = "source-derived independent C++/OpenSSL oracle"
	generatorVersion         = "Ceph 20.2.0 contract"
	upstreamGeneratorTool    = "Ceph FrameAssembler via libceph-common.so.2"
	upstreamGeneratorVersion = "ceph-common-20.2.4-0.el9"
	bannerLicense            = "LGPL-2.1-or-later"
	compositeLicense         = "(LGPL-2.1-or-later AND BSD-3-Clause)"
)

var (
	bannerPaths = []string{"src/include/msgr.h"}
	crcPaths    = []string{"src/include/msgr.h", "src/include/crc32c.h", "src/common/sctp_crc32.c", "src/msg/async/frames_v2.h", "src/msg/async/frames_v2.cc"}
	securePaths = []string{"src/include/msgr.h", "src/include/crc32c.h", "src/common/sctp_crc32.c", "src/msg/async/frames_v2.h", "src/msg/async/frames_v2.cc", "src/msg/async/crypto_onwire.h", "src/msg/async/crypto_onwire.cc"}
)

type fixtureExpectation struct {
	hash     string
	paths    []string
	license  string
	upstream bool
}

func expectedFixtures() map[string]fixtureExpectation {
	return map[string]fixtureExpectation{
		"banner-rev1.bin":         {hash: "6819c56d3d3d3ccaa0545a80d55aaa8088d88e9f849113cdafa58feb298cfcca", paths: bannerPaths, license: bannerLicense},
		"crc-four-segment.bin":    {hash: "0fa63a785151214c426f128141faf3969eb0be008b9229505ab7146401dd8c42", paths: crcPaths, license: compositeLicense},
		"crc-one-segment.bin":     {hash: "cc92c26d26b0ad4635944e3d2ac05a6cc87463162cd66a9f2884303fd95d37d4", paths: crcPaths, license: compositeLicense},
		"secure-multi-record.bin": {hash: "f0c516007c9473215ababf72c8ab9058e8a5936cab97e2ca59fdde28849d37a1", paths: securePaths, license: compositeLicense},
		"secure-one-segment.bin":  {hash: "592152e22495cecb210cf5a7bfefac49f6cdd8bbbb14e223db3538bef0b3926d", paths: securePaths, license: compositeLicense},
	}
}

func expectedUpstreamFixtures() map[string]fixtureExpectation {
	return map[string]fixtureExpectation{
		"upstream-ack-control.bin":              {hash: "2496a22ad0abda5947019dcdbd5dfe482eab124a649d302cba119df923a6ce70", paths: crcPaths, license: compositeLicense, upstream: true},
		"upstream-crc-disabled-one-segment.bin": {hash: "68cef6e79159b37891d93457c98a1748a311a6becc12cf2a67a7da90234e7569", paths: crcPaths, license: compositeLicense, upstream: true},
		"upstream-crc-four-segment.bin":         {hash: "0fa63a785151214c426f128141faf3969eb0be008b9229505ab7146401dd8c42", paths: crcPaths, license: compositeLicense, upstream: true},
		"upstream-crc-one-segment.bin":          {hash: "cc92c26d26b0ad4635944e3d2ac05a6cc87463162cd66a9f2884303fd95d37d4", paths: crcPaths, license: compositeLicense, upstream: true},
		"upstream-message-frame.bin":            {hash: "00a22987b019e085cf811b10852000116e3c63adc33bf86729485a2ecb81ff26", paths: crcPaths, license: compositeLicense, upstream: true},
		"upstream-secure-multi-record.bin":      {hash: "f0c516007c9473215ababf72c8ab9058e8a5936cab97e2ca59fdde28849d37a1", paths: securePaths, license: compositeLicense, upstream: true},
		"upstream-secure-one-segment.bin":       {hash: "592152e22495cecb210cf5a7bfefac49f6cdd8bbbb14e223db3538bef0b3926d", paths: securePaths, license: compositeLicense, upstream: true},
	}
}

type evidencePins struct {
	repository          string
	commit              string
	qualificationCommit string
	image               string
}

type manifest struct {
	SchemaVersion int       `json:"schema_version"`
	Fixture       string    `json:"fixture"`
	SHA256        string    `json:"sha256"`
	Kind          string    `json:"kind"`
	Source        source    `json:"source"`
	Generator     generator `json:"generator"`
	Secrets       secrets   `json:"secrets"`
	License       license   `json:"license"`
}

type source struct {
	Repository string   `json:"repository"`
	Commit     string   `json:"commit"`
	Paths      []string `json:"paths"`
}

type generator struct {
	Tool    string   `json:"tool"`
	Version string   `json:"version"`
	Command []string `json:"command"`
	Image   string   `json:"image"`
}

type secrets struct {
	ContainsSecrets bool `json:"contains_secrets"`
	SyntheticOnly   bool `json:"synthetic_only"`
}

type license struct {
	UpstreamExpression string `json:"upstream_expression"`
	Redistribution     string `json:"redistribution"`
	ReviewedBy         string `json:"reviewed_by"`
}

type evidence struct {
	SchemaVersion      int               `json:"schema_version"`
	Status             string            `json:"status"`
	Source             evidenceSource    `json:"source"`
	LocalToolchain     localToolchain    `json:"local_toolchain"`
	Commands           []commandResult   `json:"commands"`
	Fixtures           map[string]string `json:"fixtures"`
	DockerReproduction reproduction      `json:"docker_reproduction"`
	UpstreamOracle     upstreamOracle    `json:"upstream_oracle"`
}

type evidenceSource struct {
	Repository string `json:"repository"`
	Tag        string `json:"tag"`
	Commit     string `json:"commit"`
}

type localToolchain struct {
	Compiler string `json:"compiler"`
	OpenSSL  string `json:"openssl"`
}

type commandResult struct {
	Command string `json:"command"`
	Result  string `json:"result"`
}

type reproduction struct {
	Command string `json:"command"`
	Result  string `json:"result"`
	Reason  string `json:"reason"`
}

type upstreamOracle struct {
	Kind                string            `json:"kind"`
	Result              string            `json:"result"`
	SourceTag           string            `json:"source_tag"`
	SourceCommit        string            `json:"source_commit"`
	RuntimePackage      string            `json:"runtime_package"`
	Libraries           map[string]string `json:"libraries"`
	OracleSHA256        string            `json:"oracle_sha256"`
	DockerfileSHA256    string            `json:"dockerfile_sha256"`
	ReproductionCommand string            `json:"reproduction_command"`
}

func main() {
	pins := loadEvidence()
	fixtures := expectedFixtures()
	upstreamFixtures := expectedUpstreamFixtures()
	checkP02Evidence(pins, fixtures, upstreamFixtures)
	checkHash("integration/p02/oracle.cc", oracleSHA256)
	checkHash("integration/p02/Dockerfile", dockerfileSHA256)
	checkHash("integration/p02/centos-stream.repo", repositorySHA256)
	checkHash("integration/p02/upstream_oracle.cc", upstreamOracleSHA256)
	checkHash("integration/p02/Dockerfile.upstream", upstreamDockerfileSHA256)
	checkHash("integration/p02/reproduce-upstream.sh", upstreamReproduceSHA256)
	checkExecutable("integration/p02/reproduce.sh")
	checkExecutable("integration/p02/reproduce-upstream.sh")

	entries, err := os.ReadDir(fixtureDirectory)
	must(err)
	names := make([]string, 0, len(entries))
	for _, entry := range entries {
		if entry.IsDir() {
			if entry.Name() != "upstream" {
				fatalf("unexpected P02 fixture directory %s", entry.Name())
			}
			continue
		}
		names = append(names, entry.Name())
	}
	must(validateArtifactNames(names, fixtures))
	for name, expectation := range fixtures {
		checkFixture(fixtureDirectory, name, expectation, pins)
	}

	upstreamEntries, err := os.ReadDir(upstreamFixtureDirectory)
	must(err)
	upstreamNames := make([]string, 0, len(upstreamEntries))
	for _, entry := range upstreamEntries {
		if entry.IsDir() {
			fatalf("unexpected upstream P02 fixture directory %s", entry.Name())
		}
		upstreamNames = append(upstreamNames, entry.Name())
	}
	must(validateArtifactNames(upstreamNames, upstreamFixtures))
	for name, expectation := range upstreamFixtures {
		checkFixture(upstreamFixtureDirectory, name, expectation, pins)
	}
	fmt.Println("P02 verification passed")
}

func validateArtifactNames(names []string, expected map[string]fixtureExpectation) error {
	wantFiles := make(map[string]bool, len(expected)*2)
	for name := range expected {
		wantFiles[name] = true
		wantFiles[name+".json"] = true
	}
	for _, name := range names {
		if !wantFiles[name] {
			return fmt.Errorf("unexpected P02 fixture artifact %s", name)
		}
		delete(wantFiles, name)
	}
	if len(wantFiles) != 0 {
		return fmt.Errorf("missing P02 fixture artifacts: %v", wantFiles)
	}
	return nil
}

func loadEvidence() evidencePins {
	var value struct {
		Ceph struct {
			Repository     string `json:"repository"`
			SourceBaseline struct {
				Commit string `json:"commit"`
			} `json:"source_baseline"`
			QualificationRelease struct {
				Commit string `json:"commit"`
			} `json:"qualification_release"`
		} `json:"ceph"`
		Images struct {
			Qualification struct {
				Reference string `json:"reference"`
			} `json:"qualification"`
		} `json:"images"`
	}
	data, err := os.ReadFile("docs/p00/evidence.json")
	must(err)
	must(json.Unmarshal(data, &value))
	if value.Ceph.Repository == "" || value.Ceph.SourceBaseline.Commit == "" || value.Ceph.QualificationRelease.Commit == "" || value.Images.Qualification.Reference == "" {
		fatalf("P00 evidence lacks P02 pins")
	}
	return evidencePins{
		repository:          value.Ceph.Repository,
		commit:              value.Ceph.SourceBaseline.Commit,
		qualificationCommit: value.Ceph.QualificationRelease.Commit,
		image:               value.Images.Qualification.Reference,
	}
}

func checkHash(path, want string) {
	data, err := os.ReadFile(path)
	must(err)
	digest := sha256.Sum256(data)
	if got := hex.EncodeToString(digest[:]); got != want {
		fatalf("%s hash is %s, want %s", path, got, want)
	}
}

func checkExecutable(path string) {
	info, err := os.Stat(path)
	must(err)
	if !info.Mode().IsRegular() || info.Mode().Perm()&0111 == 0 {
		fatalf("%s must be a regular executable file", path)
	}
}

func checkFixture(directory, name string, want fixtureExpectation, pins evidencePins) {
	fixturePath := filepath.Join(directory, name)
	data, err := os.ReadFile(fixturePath)
	must(err)
	digest := sha256.Sum256(data)
	actualHash := hex.EncodeToString(digest[:])
	if actualHash != want.hash {
		fatalf("fixture %s hash is %s, want %s", name, actualHash, want.hash)
	}

	manifestPath := fixturePath + ".json"
	manifestData, err := os.ReadFile(manifestPath)
	must(err)
	must(validateManifestDocument(manifestData))
	var value manifest
	decodeStrict(manifestPath, &value)
	wantKind := "native-oracle"
	wantCommit := pins.commit
	wantTool := generatorTool
	wantVersion := generatorVersion
	wantCommand := []string{"./integration/p02/reproduce.sh"}
	if want.upstream {
		wantKind = "upstream-ceph-frameassembler"
		wantCommit = pins.qualificationCommit
		wantTool = upstreamGeneratorTool
		wantVersion = upstreamGeneratorVersion
		wantCommand = []string{"./integration/p02/reproduce-upstream.sh"}
	}
	if value.SchemaVersion != 1 || value.Fixture != name || value.SHA256 != want.hash || value.Kind != wantKind {
		fatalf("fixture %s identity or hash metadata is invalid", name)
	}
	if value.Source.Repository != pins.repository || value.Source.Commit != wantCommit || !slices.Equal(value.Source.Paths, want.paths) {
		fatalf("fixture %s source provenance is not pinned", name)
	}
	if value.Generator.Tool != wantTool || value.Generator.Version != wantVersion || value.Generator.Image != pins.image || !slices.Equal(value.Generator.Command, wantCommand) {
		fatalf("fixture %s generator is not pinned", name)
	}
	if value.Secrets.ContainsSecrets || !value.Secrets.SyntheticOnly {
		fatalf("fixture %s is not marked synthetic and secret-free", name)
	}
	if value.License.UpstreamExpression != want.license || value.License.Redistribution != "pending" || value.License.ReviewedBy != "pending human review" {
		fatalf("fixture %s has incorrect license or redistribution metadata", name)
	}
}

func checkP02Evidence(pins evidencePins, fixtures, upstreamFixtures map[string]fixtureExpectation) {
	data, err := os.ReadFile(evidencePath)
	must(err)
	must(validateEvidenceDocument(data))
	var value evidence
	decodeStrict(evidencePath, &value)
	if value.SchemaVersion != 1 || value.Status != "incomplete/pending-human-review" {
		fatalf("P02 evidence status is invalid")
	}
	if value.Source.Repository != pins.repository || value.Source.Tag != "v20.2.0" || value.Source.Commit != pins.commit {
		fatalf("P02 evidence source is not pinned")
	}
	if value.LocalToolchain.Compiler != "Apple clang 21" || value.LocalToolchain.OpenSSL != "OpenSSL 3.6.4" {
		fatalf("P02 local toolchain evidence is invalid")
	}
	wantCommands := []commandResult{
		{Command: "gofmt -w tools/p02-verify/main.go tools/p02-verify/main_test.go", Result: "passed"},
		{Command: "go test ./tools/p02-verify ./internal/msgr", Result: "passed"},
		{Command: "CGO_ENABLED=0 go test ./...", Result: "passed"},
		{Command: "go run ./tools/p02-verify", Result: "passed"},
		{Command: "make unit-p02 differential-p02 integration-p02", Result: "passed"},
		{Command: "git diff --check", Result: "passed"},
	}
	if !slices.Equal(value.Commands, wantCommands) {
		fatalf("P02 evidence commands or results are invalid")
	}
	if len(value.Fixtures) != len(fixtures)+len(upstreamFixtures) {
		fatalf("P02 evidence fixture set is incomplete")
	}
	for name, fixture := range fixtures {
		if value.Fixtures[name] != fixture.hash {
			fatalf("P02 evidence hash for %s is %q, want %q", name, value.Fixtures[name], fixture.hash)
		}
	}
	for name, fixture := range upstreamFixtures {
		if value.Fixtures["upstream/"+name] != fixture.hash {
			fatalf("P02 upstream evidence hash for %s is %q, want %q", name, value.Fixtures["upstream/"+name], fixture.hash)
		}
	}
	if value.DockerReproduction.Command != "make reproduce-p02" || value.DockerReproduction.Result != "passed" || value.DockerReproduction.Reason != "" {
		fatalf("P02 Docker reproduction evidence is invalid")
	}
	if value.UpstreamOracle.Kind != "Ceph FrameAssembler" || value.UpstreamOracle.Result != "passed" ||
		value.UpstreamOracle.SourceTag != "v20.2.4" || value.UpstreamOracle.SourceCommit != pins.qualificationCommit || value.UpstreamOracle.RuntimePackage != upstreamGeneratorVersion ||
		!maps.Equal(value.UpstreamOracle.Libraries, map[string]string{"linux/amd64": "9c425c87dbf6ebf26a43c2433619ad5b560addceecf667190287ed772b4113bf", "linux/arm64": "a4c5493230ae810de4dd3c2fe818c666441af83d2be2ce5873b9788fdd37cbdb"}) ||
		value.UpstreamOracle.OracleSHA256 != upstreamOracleSHA256 || value.UpstreamOracle.DockerfileSHA256 != upstreamDockerfileSHA256 ||
		value.UpstreamOracle.ReproductionCommand != "make reproduce-p02-upstream" {
		fatalf("P02 upstream oracle gate is invalid")
	}
}

func validateEvidenceDocument(data []byte) error {
	var typed evidence
	if err := decodeDocument(data, &typed); err != nil {
		return err
	}
	var value map[string]any
	if err := json.Unmarshal(data, &value); err != nil {
		return err
	}
	checks := []struct {
		value map[string]any
		keys  []string
	}{{value, []string{"schema_version", "status", "source", "local_toolchain", "commands", "fixtures", "docker_reproduction", "upstream_oracle"}}}
	for _, nested := range []struct {
		key  string
		keys []string
	}{
		{"source", []string{"repository", "tag", "commit"}},
		{"local_toolchain", []string{"compiler", "openssl"}},
		{"docker_reproduction", []string{"command", "result", "reason"}},
		{"upstream_oracle", []string{"kind", "result", "source_tag", "source_commit", "runtime_package", "libraries", "oracle_sha256", "dockerfile_sha256", "reproduction_command"}},
	} {
		object, err := object(value, nested.key)
		if err != nil {
			return err
		}
		checks = append(checks, struct {
			value map[string]any
			keys  []string
		}{object, nested.keys})
	}
	for _, check := range checks {
		if err := requireKeys(check.value, check.keys...); err != nil {
			return err
		}
	}
	commands, ok := value["commands"].([]any)
	if !ok || len(commands) == 0 {
		return errors.New("evidence commands must not be empty")
	}
	for index, raw := range commands {
		command, ok := raw.(map[string]any)
		if !ok {
			return fmt.Errorf("evidence command %d must be an object", index)
		}
		if err := requireKeys(command, "command", "result"); err != nil {
			return fmt.Errorf("evidence command %d: %w", index, err)
		}
	}
	return nil
}

func validateManifestDocument(data []byte) error {
	var typed manifest
	decoder := json.NewDecoder(bytes.NewReader(data))
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(&typed); err != nil {
		return err
	}
	var trailing any
	if err := decoder.Decode(&trailing); err != io.EOF {
		if err == nil {
			return errors.New("manifest contains multiple JSON values")
		}
		return err
	}
	var value map[string]any
	if err := json.Unmarshal(data, &value); err != nil {
		return err
	}
	checks := []struct {
		value map[string]any
		keys  []string
	}{{value, []string{"schema_version", "fixture", "sha256", "kind", "source", "generator", "secrets", "license"}}}
	for _, nested := range []struct {
		key  string
		keys []string
	}{
		{"source", []string{"repository", "commit", "paths"}},
		{"generator", []string{"tool", "version", "command", "image"}},
		{"secrets", []string{"contains_secrets", "synthetic_only"}},
		{"license", []string{"upstream_expression", "redistribution", "reviewed_by"}},
	} {
		object, err := object(value, nested.key)
		if err != nil {
			return err
		}
		checks = append(checks, struct {
			value map[string]any
			keys  []string
		}{object, nested.keys})
	}
	for _, check := range checks {
		if err := requireKeys(check.value, check.keys...); err != nil {
			return err
		}
	}
	return nil
}

func object(value map[string]any, key string) (map[string]any, error) {
	object, ok := value[key].(map[string]any)
	if !ok {
		return nil, fmt.Errorf("field %s must be an object", key)
	}
	return object, nil
}

func requireKeys(value map[string]any, keys ...string) error {
	for _, key := range keys {
		if _, ok := value[key]; !ok {
			return fmt.Errorf("manifest lacks required field %s", key)
		}
	}
	return nil
}

func decodeStrict(path string, value any) {
	data, err := os.ReadFile(path)
	must(err)
	must(decodeDocument(data, value))
}

func decodeDocument(data []byte, value any) error {
	decoder := json.NewDecoder(bytes.NewReader(data))
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(value); err != nil {
		return err
	}
	var trailing any
	if err := decoder.Decode(&trailing); err != io.EOF {
		if err == nil {
			return errors.New("document contains multiple JSON values")
		}
		return err
	}
	return nil
}

func must(err error) {
	if err != nil {
		fatalf("%v", err)
	}
}

func fatalf(format string, arguments ...any) {
	fmt.Fprintf(os.Stderr, "p02-verify: "+format+"\n", arguments...)
	os.Exit(1)
}
